package game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.FancyGroundFactory;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.World;
import game.actions.PurchaseAction;
import game.actions.TravelActorAction;
import game.actors.Player;
import game.actors.creatures.Humanoid;
import game.displays.FancyMessage;
import game.grounds.growinggrounds.GrowingGround;
import game.grounds.growinggrounds.GrowingStage;
import game.grounds.growinggrounds.inheritrees.InheritreeMature;
import game.grounds.growinggrounds.inheritrees.InheritreeSapling;
import game.grounds.*;
import game.grounds.growinggrounds.inheritrees.InheritreeSprout;
import game.grounds.growinggrounds.inheritrees.InheritreeYoung;
import game.items.Astley;
import game.items.LargeBolt;
import game.items.MetalSheet;
import game.items.ToiletPaperRoll;
import game.items.specialscraps.consumablescraps.*;
import game.items.specialscraps.teleportscraps.Theseus;
import game.items.specialscraps.weaponscraps.DragonSlayerReplica;
import game.items.specialscraps.weaponscraps.MetalPipe;
import game.spawners.actorspawners.AlienBugSpawner;
import game.spawners.actorspawners.HuntsmanSpiderSpawner;
import game.spawners.itemspawners.ItemSpawner;
import game.spawners.actorspawners.SuspiciousAstronautSpawner;

/**
 * The main class to start the game.
 * Created by:
 * @author Adrian Kristanto
 * Modified by:
 * @author Richard Viera
 */
public class Application {

    public static void main(String[] args) {
        World world = new World(new Display());

        FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(),
                new Wall(), new Floor(), new Puddle());

        List<String> polymorphiaBaseMap = Arrays.asList(
                        "...~~~~.........~~~...........",
                        "...~~~~.......................",
                        "...~~~........................",
                        "..............................",
                        ".............#####............",
                        ".............#___#...........~",
                        ".............#___#..........~~",
                        ".............##_##.........~~~",
                        ".................~~........~~~",
                        "................~~~~.......~~~",
                        ".............~~~~~~~........~~",
                        "......~.....~~~~~~~~.........~",
                        ".....~~~...~~~~~~~~~..........",
                        ".....~~~~~~~~~~~~~~~~........~",
                        ".....~~~~~~~~~~~~~~~~~~~....~~");
        GameMap polymorphia = new GameMap(groundFactory, polymorphiaBaseMap);
        world.addGameMap(polymorphia);

        List<GrowingGround> polymorphiaInheritrees = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            List<GrowingStage> polymorphiaInheritreeStages = new ArrayList<>();
            polymorphiaInheritreeStages.add(new InheritreeSapling(new ItemSpawner(30, new SmallFruit()), 5));
            polymorphiaInheritreeStages.add(new InheritreeMature(new ItemSpawner(20, new LargeFruit()), Integer.MAX_VALUE));
            polymorphiaInheritrees.add(new GrowingGround(polymorphiaInheritreeStages));
        }

        polymorphia.at(11, 8).setGround(polymorphiaInheritrees.get(0));
        polymorphia.at(14, 13).setGround(polymorphiaInheritrees.get(1));
        polymorphia.at(1, 2).setGround(polymorphiaInheritrees.get(2));
        polymorphia.at(14, 10).setGround(polymorphiaInheritrees.get(3));
        polymorphia.at(12, 1).setGround(polymorphiaInheritrees.get(4));

        polymorphia.at(5, 8).addItem(new MetalSheet());
        polymorphia.at(7, 8).addItem(new LargeBolt());
        polymorphia.at(8, 8).addItem(new MetalPipe());
        polymorphia.at(12, 14).addItem(new JarOfPickles());
        polymorphia.at(12, 13).addItem(new PotOfGold());
        polymorphia.at(6, 7).addItem(new EnergyDrink());
        
        polymorphia.at(12, 12).setGround(new Crater(new HuntsmanSpiderSpawner(5)));
        polymorphia.at(15, 9).setGround(new Crater(new AlienBugSpawner(10)));
        polymorphia.at(14, 14).setGround(new Crater(new SuspiciousAstronautSpawner(5)));

        List<String> factoryBaseMap = Arrays.asList(
                ".......",
                ".#####.",
                ".#___#.",
                ".#___#.",
                ".##_##.",
                ".......",
                ".......",
                ".......",
                ".......",
                ".......");
        GameMap factory = new GameMap(groundFactory, factoryBaseMap);
        world.addGameMap(factory);

        factory.at(3, 9).addActor(new Humanoid());

        List<String> refactorioBaseMap = Arrays.asList(
                "..........................~~~~",
                "..........................~~~~",
                "..........................~~~~",
                "~..........................~..",
                "~~...........#####............",
                "~~~..........#___#............",
                "~~~..........#___#............",
                "~~~..........##_##............",
                "~~~..................~~.......",
                "~~~~................~~~~......",
                "~~~~...............~~~~~......",
                "..~................~~~~.......",
                "....................~~........",
                ".............~~...............",
                "............~~~~..............");
        GameMap refactorio = new GameMap(groundFactory, refactorioBaseMap);
        world.addGameMap(refactorio);

        List<GrowingGround> refactorioInheritrees = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            List<GrowingStage> refactorioInheritreeStages = new ArrayList<>();
            refactorioInheritreeStages.add(new InheritreeSprout(3));
            refactorioInheritreeStages.add(new InheritreeSapling(new ItemSpawner(30, new SmallFruit()), 5));
            refactorioInheritreeStages.add(new InheritreeYoung(6));
            refactorioInheritreeStages.add(new InheritreeMature(new ItemSpawner(20, new LargeFruit()), Integer.MAX_VALUE));
            refactorioInheritrees.add(new GrowingGround(refactorioInheritreeStages));
        }

        refactorio.at(11, 8).setGround(refactorioInheritrees.get(0));
        refactorio.at(14, 13).setGround(refactorioInheritrees.get(1));
        refactorio.at(1, 2).setGround(refactorioInheritrees.get(2));
        refactorio.at(14, 10).setGround(refactorioInheritrees.get(3));
        refactorio.at(12, 1).setGround(refactorioInheritrees.get(4));

        Action refactorioTravel = new TravelActorAction(refactorio.at(15,6),"Refactorio");
        Action factoryTravel = new TravelActorAction(factory.at(3,3),"Static Factory");
        Action polymorphiaTravel = new TravelActorAction(polymorphia.at(15,6),"Polymorphia");
        Action swordPurchase = new PurchaseAction(new DragonSlayerReplica());
        Action toiletPurchase = new PurchaseAction(new ToiletPaperRoll());
        Action drinkPurchase = new PurchaseAction(new EnergyDrink());
        Action theseusPurchase = new PurchaseAction(new Theseus());
        Action astleyPurchase = new PurchaseAction(new Astley());

        ActionList polymorphiaTerminalAction = new ActionList();
        polymorphiaTerminalAction.add(swordPurchase);
        polymorphiaTerminalAction.add(toiletPurchase);
        polymorphiaTerminalAction.add(drinkPurchase);
        polymorphiaTerminalAction.add(theseusPurchase);
        polymorphiaTerminalAction.add(astleyPurchase);
        polymorphiaTerminalAction.add(refactorioTravel);
        polymorphiaTerminalAction.add(factoryTravel);
        ComputerTerminal polymorphiaTerminal = new ComputerTerminal(polymorphiaTerminalAction);
        polymorphia.at(15,5).setGround(polymorphiaTerminal);

        ActionList factoryTerminalAction = new ActionList();
        factoryTerminalAction.add(swordPurchase);
        factoryTerminalAction.add(toiletPurchase);
        factoryTerminalAction.add(drinkPurchase);
        factoryTerminalAction.add(theseusPurchase);
        factoryTerminalAction.add(astleyPurchase);
        factoryTerminalAction.add(refactorioTravel);
        factoryTerminalAction.add(polymorphiaTravel);
        ComputerTerminal factory_shop = new ComputerTerminal(factoryTerminalAction);
        factory.at(3,2).setGround(factory_shop);

        ActionList refactorioTerminalAction = new ActionList();
        refactorioTerminalAction.add(swordPurchase);
        refactorioTerminalAction.add(toiletPurchase);
        refactorioTerminalAction.add(drinkPurchase);
        refactorioTerminalAction.add(theseusPurchase);
        refactorioTerminalAction.add(astleyPurchase);
        refactorioTerminalAction.add(factoryTravel);
        refactorioTerminalAction.add(polymorphiaTravel);
        ComputerTerminal moon_shop = new ComputerTerminal(refactorioTerminalAction);
        refactorio.at(15,5).setGround(moon_shop);


        for (String line : FancyMessage.TITLE.split("\n")) {
            new Display().println(line);
            try {
                Thread.sleep(200);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }

        Player player = new Player("Intern", '@', 4);
        player.addBalance(122222);
        world.addPlayer(player, polymorphia.at(15, 6));

        world.run();
    }
}
