package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.MonologueAction;
import game.attributes.Purchasable;

import java.util.ArrayList;

/**
 * Purchasable device from the computer terminal, will take a subscription fee every 5 turns
 * When paid for, player can listen to it's wise words
 * Created by:
 * @author Jackie Nguyen
 * Modified by:
 * @author Richard Viera
 */
public class Astley extends Item implements Purchasable {

    private static final int PURCHASE_COST = 50;

    private static final int SUBSCRIPTION_FEE = 1;

    private static final int MONO_ITEM_THRESHOLD = 10;

    private static final int MONO_CREDIT_THRESHOLD = 50;

    private static final int MONO_HEALTH_THRESHOLD = 2;

    private static final int SUBSCRIPTION_RATE = 5;
    private static final String ASTLEY_DISPLAY_NAME = "Astley, an AI device";

    private boolean paid = true;


    private int counter = 0;

    /**
     * Constructor for the Astley class.
     */
    public Astley() {
        super(Astley.ASTLEY_DISPLAY_NAME, 'z', true);

    }

    /**
     * Based on certain conditions, Astley can give new different monolouges.
     * Will give the owner an option to listen to it.
     *
     * @param owner the actor that owns the item.
     * @return the possible actions that could be done by Astley.
     */
    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        if (this.paid){
            ArrayList<String> monologueOptions = new ArrayList<>();

            monologueOptions.add("The Factory will never gonna give you up, valuable intern!");
            monologueOptions.add("We promise we never gonna let you down with a range of staff benefits");
            monologueOptions.add("We never gonna run around and desert you, dear intern!");

            if(itemCheck(owner)) {
                monologueOptions.add("We never gonna make you cry with unfair compensation.");
            }

            if(healthCheck((owner))) {
                monologueOptions.add("Don't worry,we never gonna tell a lie and hurt you, unlike those hostile creatures");
            }

            if(creditCheck(owner)){
                monologueOptions.add("Trust is essential in this business. We promise we never gonna say goodbye to a valuable intern like you");
            }
            actions.add(new MonologueAction(Astley.ASTLEY_DISPLAY_NAME, monologueOptions));
        }

        return actions;
    }

    /**
     * Responsible for checking the actor has paid for the subscription
     * which renews every 5 turns.
     * If they have not paid for it, it will auto-renew at the next possible instance.
     *
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        super.tick(currentLocation, actor);
        this.counter += 1;

        if (this.counter >= Astley.SUBSCRIPTION_RATE) {
            if (actor.getBalance() < Astley.SUBSCRIPTION_FEE) {
                new Display().println("Not enough credits");
                this.paid = false;
            } else {
                actor.deductBalance(Astley.SUBSCRIPTION_FEE);
                new Display().println("Subscription Payment received!");
                this.paid = true;
            }

            this.counter = 0;
        }
    }


    /**
     * Checks if the item count to access to new text.
     *
     * @param actor the actor to be checked.
     * @return a boolean reflecting the condition.
     */
    private boolean itemCheck(Actor actor){
        return actor.getItemInventory().size() > Astley.MONO_ITEM_THRESHOLD;
    }

    /**
     * Checks credit of owner to unlock new text option
     *
     * @param actor the actor to be checked.
     * @return a boolean reflecting the condition.
     */
    private boolean creditCheck(Actor actor){
        return actor.getBalance() > Astley.MONO_CREDIT_THRESHOLD;
    }

    /**
     * Checks for actor's health to unlock new text
     *
     * @param actor the actor to be checked.
     * @return a boolean reflecting the condition.
     */
    private boolean healthCheck(Actor actor){
        return actor.getAttribute(BaseActorAttributes.HEALTH) < Astley.MONO_HEALTH_THRESHOLD;
    }

    /**
     * Method reflecting what happens when the item is bought.
     *
     * @param buyer the actor attempting to purchase the item.
     * @return null as there is no alternate situation in purchasing Astley.
     */
    @Override
    public String getPurchased(Actor buyer) {
        buyer.addItemToInventory(new Astley());
        return null;
    }

    /**
     * The cost of buying is returned.
     *
     * @return the cost of purchasing Astley.
     */
    @Override
    public int getPurchasePrice() {
        return Astley.PURCHASE_COST;
    }
}
