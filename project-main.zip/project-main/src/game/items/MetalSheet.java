package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.SellAction;
import game.attributes.Ability;
import game.attributes.Sellable;

import java.util.Random;

/**
 * A class representing a Metal Sheet.
 * This class extends {@link Item} and implements {@link Sellable}, enabling it to be sold
 * within the game environment.
 * Created by:
 * @author Richard Viera
 * Modified by:
 * @author Xing Su
 */

public class MetalSheet extends Item implements Sellable {
    private final static int SELL_PRICE = 20;
    private static final int SELL_EVENT_CHANCE = 60;

    /**
     * Constructor for the MetalSheet class.
     * Initializes the item with its name and display character.
     */
    public MetalSheet() {
        super("Metal sheet", '%', true);
    }

    /**
     * Attempts to remove the Metal Sheet from the seller's inventory upon selling.
     * This method implements the {@link Sellable} interface and is designed to handle
     * the transaction by removing the item from the actor's inventory.
     *
     * @param seller the Actor attempting to sell the Metal Sheet
     * @return null, indicating that the item was successfully removed from the inventory
     */
    @Override
    public String getSold(Actor seller) {
        seller.removeItemFromInventory(this);
        return null;
    }

    /**
     * Calculates the sell price of the Metal Sheet.
     * There is a 60% chance that the price will be halved, otherwise, it remains at the normal price of 20 credits.
     *
     * @return the sell price of the Metal Sheet, which is either 10 or 20 credits
     */
    @Override
    public int getSellPrice() {
        if ((new Random()).nextInt(100) < MetalSheet.SELL_EVENT_CHANCE) {
            return MetalSheet.SELL_PRICE / 2;
        } else {
            return MetalSheet.SELL_PRICE;
        }
    }

    /**
     * Returns a list of allowable actions that can be performed on this item by another actor at a specific location.
     *
     * @param otherActor the actor performing the actions.
     * @param location the location where the actions are being performed.
     * @return an ActionList of allowable actions.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();
        if (location.containsAnActor() && otherActor.hasCapability(Ability.CAN_BUY)) {
            actions.add(new SellAction(this));
        }
        return actions;
    }

}