package game.items.specialscraps.consumablescraps;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.actions.ConsumeAction;
import game.attributes.Consumable;

/**
 * SmallFruit class representing a small fruit.
 * Created by:
 * @author Richard Viera
 */
public class SmallFruit extends Item implements Consumable {

    private final static int HEAL_POINT = 1;


    /**
     * Constructor for the SmallFruit class.
     */
    public SmallFruit() {
        super("Small fruit", 'o', true);
    }

    /**
     * Provides a list of actions that can be performed with this item by the owner, typically including the option to consume.
     *
     * @param owner the actor who owns the item
     * @return an ActionList containing the ConsumeAction for this item
     */
    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        actions.add(new ConsumeAction(this));
        return actions;
    }

    /**
     * Executes the consume action, removing the item from the actor's inventory and applying its effects.
     *
     * @param consumer the actor consuming the item
     * @return a message indicating the results of the consumption
     */
    @Override
    public String getConsumed(Actor consumer) {
        consumer.removeItemFromInventory(this);
        return getEffectsOfConsumption(consumer);
    }

    /**
     * Represents the actions that happen when the small fruit is consumed.
     *
     * @param consumer the Actor consuming the thing.
     * @return the message signifying the small fruit has been eaten and will heal the player 1 point.
     */
    protected String getEffectsOfConsumption(Actor consumer) {
        consumer.heal(SmallFruit.HEAL_POINT);
        return this + " heals " + consumer + " by " + SmallFruit.HEAL_POINT + " point";
    }

    /**
     * Returns the verb associated with consuming this item.
     *
     * @return a string representing the action of consuming, like "eat" or "drink"
     */
    @Override
    public String verb() {
        return "consume";
    }
}