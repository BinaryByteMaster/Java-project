package game.items.specialscraps.consumablescraps;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.ConsumeAction;
import game.actions.SellAction;
import game.attributes.Ability;
import game.attributes.Consumable;
import game.attributes.Sellable;

/**
 * A class representing a Large Fruit.
 * This class extends {@link Item} and implements {@link Consumable}, {@link Sellable}, enabling it to be consumed
 * and sold within the game environment.
 * Created by:
 * @author Richard Viera
 * Modified by:
 * @author Xing Su
 */
public class LargeFruit extends Item implements Consumable, Sellable {

    private final static int HEAL_POINT = 2;
    private final static int SELL_PRICE = 30;

    /**
     * Constructor for the LargeFruit class.
     * Initializes the item with its name and display character.
     */
    public LargeFruit() {
        super("Large fruit", 'O', true);
    }

    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        actions.add(new ConsumeAction(this));
        return actions;
    }

    /**
     * Attempts to consume the Large Fruit.
     * This method implements the {@link Consumable} interface and is designed to handle
     * the consumption by removing the item from the actor's inventory.
     *
     * @param consumer the Actor attempting to consume the Large Fruit
     * @return the effects of consumption
     */
    @Override
    public String getConsumed(Actor consumer) {
        consumer.removeItemFromInventory(this);
        return getEffectsOfConsumption(consumer);
    }

    /**
     * Applies the effects of consuming the Large Fruit.
     * This method heals the actor by a certain amount.
     *
     * @param consumer the Actor consuming the Large Fruit
     * @return a string describing the effects of consumption
     */
    private String getEffectsOfConsumption(Actor consumer) {
        consumer.heal(LargeFruit.HEAL_POINT);
        return this + " heals " + consumer + " by " + LargeFruit.HEAL_POINT + " points";
    }

    @Override
    public String verb() {
        return "consume";
    }

    /**
     * Attempts to remove the Large Fruit from the seller's inventory upon selling.
     * This method implements the {@link Sellable} interface and is designed to handle
     * the transaction by removing the item from the actor's inventory.
     *
     * @param seller the Actor attempting to sell the Large Fruit
     * @return null, indicating that the item was successfully removed from the inventory
     */
    @Override
    public String getSold(Actor seller) {
        seller.removeItemFromInventory(this);
        return null;
    }

    /**
     * Returns the sell price of the Large Fruit.
     *
     * @return the sell price of the Large Fruit, which is 30 credits
     */
    @Override
    public int getSellPrice() {
        return LargeFruit.SELL_PRICE;
    }

    /**
     * Returns a list of allowable actions that can be performed on this item by another actor at a specific location.
     *
     * @param otherActor the actor performing the actions.
     * @param location the location where the actions are being performed.
     * @return an ActionList of allowable actions.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();
        if (location.containsAnActor() && otherActor.hasCapability(Ability.CAN_BUY)) {
            actions.add(new SellAction(this));
        }
        return actions;
    }

}