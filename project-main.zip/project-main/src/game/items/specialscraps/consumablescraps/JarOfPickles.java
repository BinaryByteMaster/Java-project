package game.items.specialscraps.consumablescraps;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.ConsumeAction;
import game.actions.SellAction;
import game.attributes.Ability;
import game.attributes.Consumable;
import game.attributes.Sellable;

import java.util.Random;

/**
 * A class representing a Jar of Pickles.
 * This class extends {@link Item} and implements {@link Consumable}, {@link Sellable}, enabling it to be consumed
 * and sold within the game environment. The effect of consuming the Jar of Pickles is subject to chance,
 * reflecting a gameplay dynamic of unpredictable outcomes.
 * Created by:
 * @author Xing Su
 * Modified by:
 * @author Richard Viera
 */
public class JarOfPickles extends Item implements Consumable, Sellable {

    private final static int HEAL_POINT = 1;
    private final static int SELL_PRICE = 25;
    private static final int SELL_EVENT_CHANCE = 50;

    /**
     * Constructor for the JarOfPickles class.
     * Initializes the item with its name and display character.
     */
    public JarOfPickles() {
        super("Jar of Pickles", 'n', true);
    }

    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        actions.add(new ConsumeAction(this));
        return actions;
    }

    /**
     * Attempts to consume the Jar of Pickles.
     * This method implements the {@link Consumable} interface and is designed to handle
     * the consumption by removing the item from the actor's inventory.
     *
     * @param consumer the Actor attempting to consume the Jar of Pickles
     * @return the effects of consumption
     */
    @Override
    public String getConsumed(Actor consumer) {
        consumer.removeItemFromInventory(this);
        return getEffectsOfConsumption(consumer);
    }

    /**
     * Applies the effects of consuming the Jar of Pickles.
     * This method either heals or hurts the actor based on a random chance.
     *
     * @param consumer the Actor consuming the Jar of Pickles
     * @return a string describing the effects of consumption
     */
    private String getEffectsOfConsumption(Actor consumer) {
        if (new Random().nextBoolean()) {
            consumer.heal(JarOfPickles.HEAL_POINT);
            return this + " heals " + consumer + " by " + JarOfPickles.HEAL_POINT + " points.";
        } else {
            consumer.hurt(JarOfPickles.HEAL_POINT);
            return this + " hurts " + consumer + " by " + JarOfPickles.HEAL_POINT + " points because it was expired.";
        }
    }

    @Override
    public String verb() {
        return "empties";
    }

    /**
     * Attempts to remove the Jar of Pickles from the seller's inventory upon selling.
     * This method implements the {@link Sellable} interface and is designed to handle
     * the transaction by removing the item from the actor's inventory.
     *
     * @param seller the Actor attempting to sell the Jar of Pickles
     * @return null, indicating that the item was successfully removed from the inventory
     */
    @Override
    public String getSold(Actor seller) {
        seller.removeItemFromInventory(this);
        return null;
    }

    /**
     * Calculates the sell price of the Jar of Pickles.
     * There is a 50% chance that the price will be doubled to 50 credits, otherwise, it remains at the normal price of 25 credits.
     *
     * @return the sell price of the Jar of Pickles, which is either 25 or 50 credits
     */
    @Override
    public int getSellPrice() {
        if ((new Random()).nextInt(100) < JarOfPickles.SELL_EVENT_CHANCE) {
            return JarOfPickles.SELL_PRICE * 2;
        } else {
            return JarOfPickles.SELL_PRICE;
        }
    }

    /**
     * Returns a list of allowable actions that can be performed on this item by another actor at a specific location.
     *
     * @param otherActor the actor performing the actions.
     * @param location the location where the actions are being performed.
     * @return an ActionList of allowable actions.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();
        if (location.containsAnActor() && otherActor.hasCapability(Ability.CAN_BUY)) {
            actions.add(new SellAction(this));
        }
        return actions;
    }

}