package game.items.specialscraps.consumablescraps;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.actions.ConsumeAction;
import game.attributes.Consumable;
import game.attributes.Purchasable;

import java.util.Random;

/**
 * Class representing an Energy Drink item that can be consumed or purchased.
 * Created by:
 * @author Xing Su
 * Modified by:
 * @author Richard Vira, Khoa Hoang Dang Ho
 */
public class EnergyDrink extends Item implements Consumable, Purchasable {

    private final static int HEAL_POINT = 1;
    private final static int PURCHASE_PRICE = 10;
    private static final int PURCHASE_EVENT_CHANCE = 20;

    /**
     * Constructor for the EnergyDrink class.
     */
    public EnergyDrink() {
        super("Energy drink", '*', true);
    }

    /**
     * Returns the list of allowable actions that can be performed on this item.
     *
     * @param owner the actor owning the item.
     * @return an ActionList of allowable actions.
     */
    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        actions.add(new ConsumeAction(this));
        return actions;
    }

    /**
     * Consumes the item, applying its effects to the consumer.
     *
     * @param consumer the actor consuming the item.
     * @return a string describing the effects of consumption.
     */
    @Override
    public String getConsumed(Actor consumer) {
        consumer.removeItemFromInventory(this);
        return getEffectsOfConsumption(consumer);
    }

    /**
     * Applies the effects of consuming the item to the consumer.
     *
     * @param consumer the actor consuming the item.
     * @return a string describing the effects of consumption.
     */
    private String getEffectsOfConsumption(Actor consumer) {
        consumer.heal(EnergyDrink.HEAL_POINT);
        return consumer + " feels energized";
    }

    /**
     * Returns the verb describing the consumption action.
     *
     * @return a string describing the consumption action.
     */
    @Override
    public String verb() {
        return "drinks";
    }

    /**
     * Adds the item to the buyer's inventory upon purchase.
     *
     * @param buyer the actor purchasing the item.
     * @return a string describing the purchase action, or null if no description is needed.
     */
    @Override
    public String getPurchased(Actor buyer) {
        buyer.addItemToInventory(this);
        return null;
    }

    /**
     * Returns the purchase price of the item.
     *
     * @return the purchase price of the item.
     */
    @Override
    public int getPurchasePrice() {
        if ((new Random()).nextInt(100) < EnergyDrink.PURCHASE_EVENT_CHANCE) {
            return 2 * EnergyDrink.PURCHASE_PRICE;
        } else {
            return EnergyDrink.PURCHASE_PRICE;
        }
    }
}