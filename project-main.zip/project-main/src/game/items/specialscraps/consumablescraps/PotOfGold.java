package game.items.specialscraps.consumablescraps;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.ConsumeAction;
import game.actions.SellAction;
import game.attributes.Ability;
import game.attributes.Consumable;
import game.attributes.Sellable;

import java.util.Random;

/**
 * A class representing a Pot of Gold.
 * This class extends {@link Item} and implements {@link Consumable}, {@link Sellable}, enabling it to be consumed
 * and sold within the game environment. The sell price of the Pot of Gold is subject to fluctuation,
 * reflecting a gameplay dynamic of fluctuating prices.
 * Created by:
 * @author Xing Su
 * Modified by:
 * @author Richard Viera
 */
public class PotOfGold extends Item implements Consumable, Sellable {

    private final static int CREDIT_AMOUNT = 10;
    private final static int SELL_PRICE = 500;
    private static final int SELL_EVENT_CHANCE = 25;

    /**
     * Constructor for the PotOfGold class.
     * Initializes the item with its name and display character.
     */
    public PotOfGold() {
        super("Pot of Gold", '$', true);
    }

    @Override
    public ActionList allowableActions(Actor owner) {
        ActionList actions = new ActionList();
        actions.add(new ConsumeAction(this));
        return actions;
    }

    /**
     * Attempts to consume the Pot of Gold.
     * This method implements the {@link Consumable} interface and is designed to handle
     * the consumption by removing the item from the actor's inventory.
     *
     * @param consumer the Actor attempting to consume the Pot of Gold
     * @return the effects of consumption
     */
    @Override
    public String getConsumed(Actor consumer) {
        consumer.removeItemFromInventory(this);
        return getEffectsOfConsumption(consumer);
    }

    /**
     * Applies the effects of consuming the Pot of Gold.
     * This method adds credits to the actor's balance.
     *
     * @param consumer the Actor consuming the Pot of Gold
     * @return a string describing the effects of consumption
     */
    private String getEffectsOfConsumption(Actor consumer) {
        consumer.addBalance(PotOfGold.CREDIT_AMOUNT);
        return consumer + " empties out " + this + " and gains " + PotOfGold.CREDIT_AMOUNT + ". The rest are withheld as tax by the factory.";
    }

    @Override
    public String verb() {
        return "opens";
    }

    /**
     * Attempts to remove the Pot of Gold from the seller's inventory upon selling.
     * This method implements the {@link Sellable} interface and is designed to handle
     * the transaction by removing the item from the actor's inventory.
     *
     * @param seller the Actor attempting to sell the Pot of Gold
     * @return null, indicating that the item was successfully removed from the inventory
     */
    @Override
    public String getSold(Actor seller) {
        seller.removeItemFromInventory(this);
        return null;
    }

    /**
     * Calculates the sell price of the Pot of Gold.
     * There is a 25% chance that the price will be 0 credits due to tax, otherwise, it remains at the normal price of 500 credits.
     *
     * @return the sell price of the Pot of Gold, which is either 0 or 500 credits
     */
    @Override
    public int getSellPrice() {
        if ((new Random()).nextInt(100) < PotOfGold.SELL_EVENT_CHANCE) {
            return 0;
        } else {
            return PotOfGold.SELL_PRICE;
        }
    }

    /**
     * Returns a list of allowable actions that can be performed on this item by another actor at a specific location.
     *
     * @param otherActor the actor performing the actions.
     * @param location the location where the actions are being performed.
     * @return an ActionList of allowable actions.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();
        if (location.containsAnActor() && otherActor.hasCapability(Ability.CAN_BUY)) {
            actions.add(new SellAction(this));
        }
        return actions;
    }

}