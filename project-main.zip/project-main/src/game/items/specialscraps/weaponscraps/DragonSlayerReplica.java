package game.items.specialscraps.weaponscraps;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AttackAction;
import game.attributes.Purchasable;
import game.attributes.Status;

import java.util.Random;

/**
 * A class representing the Dragon Slayer Replica, a powerful weapon scrap. This weapon can also
 * be purchased but has a unique purchasing mechanic where there is a chance that the purchase
 * will not yield the item despite taking credits.
 * This class extends {@link WeaponItem} and implements {@link Purchasable} to provide both
 * combat and transaction functionalities.
 * Created by:
 * @author Khoa Hoang Dang Ho
 * Modified by:
 * @author Richard Viera
 */
public class DragonSlayerReplica extends WeaponItem implements Purchasable {

    /**
     * Constructs a Dragon Slayer Replica with predefined attributes. The weapon uses
     * the 'slash' action and has a hit chance of 75%.
     */
    public DragonSlayerReplica() {
        super("Dragon Slayer Replica", 'x', 50, "slashes", 75);
    }

    /**
     * Represents the actions that can be done using the DragonSlayerReplica on another actor.
     *
     * @param otherActor the other actor
     * @param location the location of the other actor
     * @return the ActionList that contains an AttackAction using the DragonSlayerReplica
     */
    @Override
    public ActionList allowableActions (Actor otherActor, Location location) {
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Status.HOSTILE_TO_FRIENDLY)) {
            actions.add(new AttackAction(otherActor, location.toString(), this));
        }
        return actions;
    }

    /**
     * Attempts to purchase the Dragon Slayer Replica. There is a 75% chance that the credits
     * will be deducted without receiving the item. If the purchase succeeds, the item is added
     * to the buyer's inventory.
     *
     * @param buyer the actor attempting to purchase the item
     * @return a string message describing the outcome of the purchase. Returns null if the
     * purchase is successful and the item is added to the inventory.
     */
    @Override
    public String getPurchased(Actor buyer) {
        if ((new Random()).nextBoolean()) {
            buyer.addItemToInventory(this);
            return null;
        }
        else {
            return this.getPurchasePrice() + " credits are taken from " + buyer + " , but " + buyer + " doesn't receive anything in return!";
        }
    }

    /**
     * Returns the purchase price of the Dragon Slayer Replica.
     *
     * @return the cost of the item in credits, which is always 100.
     */
    @Override
    public int getPurchasePrice() {
        return 100;
    }
}
