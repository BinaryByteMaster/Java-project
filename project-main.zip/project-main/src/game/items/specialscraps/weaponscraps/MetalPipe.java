package game.items.specialscraps.weaponscraps;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AttackAction;
import game.actions.SellAction;
import game.attributes.Ability;
import game.attributes.Sellable;
import game.attributes.Status;

/**
 * A class representing a Metal Pipe.
 * This class extends {@link WeaponItem} and implements {@link Sellable}, enabling it to be used as a weapon and sold
 * within the game environment.
 * Created by:
 * @author Richard Viera
 * Modified by:
 * @author Xing Su
 */

public class MetalPipe extends WeaponItem implements Sellable {

    private final static int SELL_PRICE = 35;

    /**
     * Constructor for the MetalPipe class.
     * Initializes the item with its name, display character, damage, verb, and hit rate.
     */
    public MetalPipe() {
        super("Metal pipe", '!', 1, "whacks", 25);
    }

    /**
     * Attempts to remove the Metal Pipe from the seller's inventory upon selling.
     * This method implements the {@link Sellable} interface and is designed to handle
     * the transaction by removing the item from the actor's inventory.
     *
     * @param seller the Actor attempting to sell the Metal Pipe
     * @return null, indicating that the item was successfully removed from the inventory
     */
    @Override
    public String getSold(Actor seller) {
        seller.removeItemFromInventory(this);
        return null;
    }

    /**
     * Returns the sell price of the Metal Pipe.
     *
     * @return the sell price of the Metal Pipe, which is 35 credits
     */
    @Override
    public int getSellPrice() {
        return MetalPipe.SELL_PRICE;
    }

    /**
     * Returns a list of allowable actions that can be performed on this item by another actor at a specific location.
     *
     * @param otherActor the actor performing the actions.
     * @param location the location where the actions are being performed.
     * @return an ActionList of allowable actions.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Ability.CAN_BUY)) {
            actions.add(new SellAction(this));
        }

        if (otherActor.hasCapability(Status.HOSTILE_TO_FRIENDLY)) {
            actions.add(new AttackAction(otherActor, location.toString(), this));
        }
        return actions;
    }
}