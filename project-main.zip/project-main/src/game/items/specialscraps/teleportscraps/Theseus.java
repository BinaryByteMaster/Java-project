package game.items.specialscraps.teleportscraps;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.TravelActorAction;
import game.attributes.Purchasable;

import java.util.Random;

/**
 * A class representing a THESEUS.
 * This class extends {@link Item} and implements {@link Purchasable}, enabling it to be purchased
 * within the game environment. The purchase price of the THESEUS is subject to a high chance
 * of discount due to an oversupply, reflecting a gameplay dynamic of fluctuating prices.
 * Created by:
 * @author Khoa Hoang Dang Ho
 */
public class Theseus extends Item implements Purchasable {
    private final static int PURCHASE_PRICE = 100;
    /**
     * Constructor for the THESEUS.
     * Initializes the item with its name and display character.
     */
    public Theseus() {
        super("THESEUS", '^',true);
    }
    /**
     * Attempts to add the THESEUS to the buyer's inventory upon purchase.
     * This method implements the {@link Purchasable} interface and is designed to handle
     * the transaction by adding the item to the actor's inventory.
     *
     * @param buyer the Actor attempting to purchase the THESEUS
     * @return null, indicating that the item was successfully added to the inventory
     */
    public String getPurchased(Actor buyer){
        buyer.addItemToInventory(this);
        return null;
    }
    /**
     * Calculates the purchase price of the THESEUS.
     *
     * @return the cost of the THESEUS, which is 100 credits.
     */
    public int getPurchasePrice() {
            return Theseus.PURCHASE_PRICE;
    }
    /**
     * Provides a list of actions that can be performed with this item by the owner, typically including the option to consume.
     *
     * @param location the location of the player
     * @return an ActionList containing the TravelActorAction for this item
     */
    public ActionList allowableActions(Location location) {
        ActionList actions = super.allowableActions(location);
        Random rand = new Random();
        int x = rand.nextInt(location.map().getXRange().max());
        int y = rand.nextInt(location.map().getYRange().max());
        actions.add(new TravelActorAction(location.map().at(x,y),"current map"));
        return actions;
    }
}
