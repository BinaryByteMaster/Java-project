package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.SellAction;
import game.attributes.Ability;
import game.attributes.Purchasable;
import game.attributes.Sellable;

import java.util.Random;

/**
 * A class representing a Toilet Paper Roll.
 * This class extends {@link Item} and implements {@link Purchasable}, {@link Sellable}, enabling it to be purchased
 * and sold within the game environment. The purchase price of the Toilet Paper Roll is subject to a high chance
 * of discount due to an oversupply, reflecting a gameplay dynamic of fluctuating prices.
 * Created by:
 * @author Khoa Hoang Dang Ho
 * Modified by:
 * @author Richard Viera, Xing Su
 */
public class ToiletPaperRoll extends Item implements Purchasable, Sellable {

    private final static int PURCHASE_PRICE = 5;
    private final static int SELL_PRICE = 1;
    private static final int PURCHASE_EVENT_CHANCE = 75;

    /**
     * Constructor for the ToiletPaperRoll class.
     * Initializes the item with its name and display character.
     */
    public ToiletPaperRoll() {
        super("Toilet Paper Roll", 's', true);
    }

    /**
     * Attempts to add the Toilet Paper Roll to the buyer's inventory upon purchase.
     * This method implements the {@link Purchasable} interface and is designed to handle
     * the transaction by adding the item to the actor's inventory.
     *
     * @param buyer the Actor attempting to purchase the Toilet Paper Roll
     * @return null, indicating that the item was successfully added to the inventory
     */
    @Override
    public String getPurchased(Actor buyer){
        buyer.addItemToInventory(this);
        return null;
    }

    /**
     * Calculates the purchase price of the Toilet Paper Roll.
     * There is a 75% chance that the price will be significantly reduced to 1 credit due to oversupply,
     * otherwise, it remains at the normal price of 5 credits.
     *
     * @return the cost of the Toilet Paper Roll, which is usually 1 credit, but can sometimes be 5 credits
     */
    @Override
    public int getPurchasePrice() {
        if ((new Random()).nextInt(100) < ToiletPaperRoll.PURCHASE_EVENT_CHANCE) {
            return 1;
        }
        else {
            return ToiletPaperRoll.PURCHASE_PRICE;
        }
    }

    /**
     * Attempts to remove the Toilet Paper Roll from the seller's inventory upon selling.
     * This method implements the {@link Sellable} interface and is designed to handle
     * the transaction by removing the item from the actor's inventory.
     *
     * @param seller the Actor attempting to sell the Toilet Paper Roll
     * @return null, indicating that the item was successfully removed from the inventory
     */
    @Override
    public String getSold(Actor seller) {
        seller.removeItemFromInventory(this);

        if (new Random().nextBoolean()) {
            seller.hurt(seller.getAttribute(BaseActorAttributes.HEALTH));
            return seller + " was instantly killed by the Humanoid during the transaction!";
        }

        return null;
    }

    /**
     * Returns the sell price of the Toilet Paper Roll.
     *
     * @return the sell price of the Toilet Paper Roll, which is 1 credit
     */
    @Override
    public int getSellPrice() {
        return ToiletPaperRoll.SELL_PRICE;
    }

    /**
     * Returns a list of allowable actions that can be performed on this item by another actor at a specific location.
     *
     * @param otherActor the actor performing the actions.
     * @param location the location where the actions are being performed.
     * @return an ActionList of allowable actions.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();
        if (location.containsAnActor() && otherActor.hasCapability(Ability.CAN_BUY)) {
            actions.add(new SellAction(this));
        }
        return actions;
    }

}