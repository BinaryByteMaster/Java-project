package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.SellAction;
import game.attributes.Ability;
import game.attributes.Sellable;

/**
 * A class representing a Large Bolt.
 * This class extends {@link Item} and implements {@link Sellable}, enabling it to be sold
 * within the game environment.
 * Created by:
 * @author Richard Viera
 * Modified by:
 * @author Xing Su
 */

public class LargeBolt extends Item implements Sellable {
    private final static int SELL_PRICE = 25;

    /**
     * Constructor for the LargeBolt class.
     * Initializes the item with its name and display character.
     */
    public LargeBolt() {
        super("Large bolt", '+', true);
    }

    /**
     * Attempts to remove the Large Bolt from the seller's inventory upon selling.
     * This method implements the {@link Sellable} interface and is designed to handle
     * the transaction by removing the item from the actor's inventory.
     *
     * @param seller the Actor attempting to sell the Large Bolt
     * @return null, indicating that the item was successfully removed from the inventory
     */
    @Override
    public String getSold(Actor seller) {
        seller.removeItemFromInventory(this);
        return null;
    }

    /**
     * Returns the sell price of the Large Bolt.
     *
     * @return the sell price of the Large Bolt, which is 25 credits
     */
    @Override
    public int getSellPrice() {
        return LargeBolt.SELL_PRICE;
    }

    /**
     * Returns a list of allowable actions that can be performed on this item by another actor at a specific location.
     *
     * @param otherActor the actor performing the actions.
     * @param location the location where the actions are being performed.
     * @return an ActionList of allowable actions.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();
        if (location.containsAnActor() && otherActor.hasCapability(Ability.CAN_BUY)) {
            actions.add(new SellAction(this));
        }
        return actions;
    }

}