package game.grounds;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.PurchaseAction;
import game.attributes.Ability;
import game.attributes.Purchasable;

import java.util.List;
/**
 * A ComputerTerminal represents a type of ground in the game that allows actors with the trading capability
 * to interact with and purchase items. This class extends {@link Ground} and is designed to integrate
 * purchasing functionalities into the game environment.
 * Actors can interact with the terminal if they possess the CAN_TRADE ability, enabling them to purchase
 * items from a list of purchasable objects.
 * Created by:
 * @author Khoa Hoang Dang Ho
 */
public class ComputerTerminal extends Ground {
    public ActionList action;

    /**
     * Constructor for the ComputerTerminal class.
     * Initializes the terminal with a specified list of action.
     */
    public ComputerTerminal(ActionList newAction) {
        super('=');

        this.action = newAction;
    }

    /**
     * Provides a list of actions that can be performed at this location by an actor, specifically
     * tailored to include purchasing actions if the actor has the capability to trade.
     *
     * @param actor the actor at the terminal's location.
     * @param location the current location of the terminal.
     * @param direction the direction from the actor to the terminal, as a string.
     * @return an ActionList containing available actions at this terminal, which could include multiple PurchaseActions and TravelActorAction.
     */
    public ActionList allowableActions(Actor actor, Location location, String direction){
        ActionList actions = new ActionList();
        if(actor.hasCapability(Ability.CAN_TRADE)) {
            for (Action action: action){
                actions.add(action);
            }
        }
        return actions;
    }
}
