package game.grounds;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;

/**
 * A class that represents a wall which Actors can not go through.
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Richard Viera
 */
public class Wall extends Ground {

    /**
     * Constructor for the Wall class.
     */
    public Wall() {
        super('#');
    }

    /**
     * Checks if the Wall can be entered.
     *
     * @param actor the Actor to check.
     * @return false because actors can not enter the wall ground.
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
    }
}
