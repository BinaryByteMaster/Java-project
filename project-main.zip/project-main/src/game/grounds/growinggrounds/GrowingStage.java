package game.grounds.growinggrounds;

import edu.monash.fit2099.engine.positions.Location;

/**
 * Abstract GrowingStage Class representing stages of growth transformations.
 * Created by:
 * @author Richard Viera
 */
public abstract class GrowingStage {
    private int currentAge = 0;
    private final int matureAge;
    private final char displayChar;

    /**
     * Constructor for the GrowingStage class.
     *
     * @param matureAge the age when the stage reaches maturity.
     * @param displayChar the char that is used to display this stage in the game.
     */
    public GrowingStage(int matureAge, char displayChar) {
        this.matureAge = matureAge;
        this.displayChar = displayChar;
    }

    /**
     * Getter for the display character of the stage.
     *
     * @return the display char of the stage.
     */
    public char getDisplayChar() {
        return displayChar;
    }

    /**
     * Getter for the maturity state of the stage which is determined by checking
     * is the current age at least equal to the mature age.
     *
     * @return boolean representing the maturity of the stage.
     */
    public boolean isMature() {
        return this.currentAge >= this.matureAge;
    }

    /**
     * Method representing what happens every specified annual time interval.
     *
     * @param location the location of the current stage.
     */
    public void stageTickAction(Location location) {
        this.currentAge += 1;
    }
}
