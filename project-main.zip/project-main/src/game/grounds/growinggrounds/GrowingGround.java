package game.grounds.growinggrounds;

import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;

import java.util.List;

/**
 * GrowingGround Class representing terrain that has the ability to transform.
 * Created by:
 * @author Richard Viera
 */
public class GrowingGround extends Ground {

    private static final int STARTING_INDEX = 0;
    private static final int GROWTH_VALUE_EVERY_TURN = 1;
    private static final int CHECK_FOR_FOLLOWING_STAGE = 1;
    private final List<GrowingStage> stages;
    private int currentStage;

    /**
     * Constructor for the GrowingGround class.
     *
     * @param growingStages a list of GrowingStages which represents the various stages of the ground.
     */
    public GrowingGround(List<GrowingStage> growingStages) {
        super(growingStages.get(GrowingGround.STARTING_INDEX).getDisplayChar());
        this.currentStage = GrowingGround.STARTING_INDEX;
        this.stages = growingStages;
    }

    /**
     * Method representing the passing of time. Registers the current age of the GrowingGround instance.
     *
     * @param location The location of the Ground.
     */
    @Override
    public void tick(Location location) {
        if (this.currentStage + GrowingGround.CHECK_FOR_FOLLOWING_STAGE < this.stages.size()) {
            if (this.stages.get(this.currentStage).isMature()) {
                this.currentStage += GrowingGround.GROWTH_VALUE_EVERY_TURN;
                super.setDisplayChar(this.stages.get(this.currentStage).getDisplayChar());
            }
        }

        this.stages.get(this.currentStage).stageTickAction(location);
    }
}
