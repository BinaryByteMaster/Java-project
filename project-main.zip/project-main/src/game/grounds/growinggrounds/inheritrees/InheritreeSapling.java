package game.grounds.growinggrounds.inheritrees;

import edu.monash.fit2099.engine.positions.Location;
import game.grounds.growinggrounds.GrowingStage;
import game.spawners.*;

/**
 * InheritreeSapling class representing the sapling stage of the Inheritree.
 * Created by:
 * @author Richard Viera
 * Modified by:
 * @author Jackie Nguyen
 */
public class InheritreeSapling extends GrowingStage {

    private final Spawner spawner;

    /**
     * Constructor for the InheritreeSapling class.
     *
     * @param spawner spawner class which spawns Items around the location.
     * @param matureAge the age when the InheritreeSapling stage matures.
     */
    public InheritreeSapling(Spawner spawner, int matureAge) {
        super(matureAge, 't');
        this.spawner = spawner;
    }

    /**
     * Represents the passing of time felt by the InheritreeSapling object.
     *
     * @param location The location of the Ground.
     */
    @Override
    public void stageTickAction(Location location) {
        this.spawner.spawn(location);
        super.stageTickAction(location);
    }
}
