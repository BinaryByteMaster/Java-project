package game.grounds.growinggrounds.inheritrees;

import game.grounds.growinggrounds.GrowingStage;

/**
 * InheritreeYoung class representing the young stage of the Inheritree.
 * Created by:
 * @author Richard Viera
 */
public class InheritreeYoung extends GrowingStage {

    /**
     * Constructor for the InheritreeYoung class.
     *
     * @param matureAge the age when the InheritreeYoung stage matures.
     */
    public InheritreeYoung(int matureAge) {
        super(matureAge, 'y');
    }
}
