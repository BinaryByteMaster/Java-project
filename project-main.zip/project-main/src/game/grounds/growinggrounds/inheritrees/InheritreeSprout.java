package game.grounds.growinggrounds.inheritrees;

import game.grounds.growinggrounds.GrowingStage;

/**
 * InheritreeSprout class representing the sprout stage of the Inheritree.
 * Created by:
 * @author Richard Viera
 */
public class InheritreeSprout extends GrowingStage {

    /**
     * Constructor for the InheritreeSprout class.
     *
     * @param matureAge the age when the InheritreeSprout stage matures.
     */
    public InheritreeSprout(int matureAge) {
        super(matureAge, ',');
    }
}
