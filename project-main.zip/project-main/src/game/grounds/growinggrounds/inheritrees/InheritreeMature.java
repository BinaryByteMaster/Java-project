package game.grounds.growinggrounds.inheritrees;

import edu.monash.fit2099.engine.positions.Location;
import game.grounds.growinggrounds.GrowingStage;
import game.spawners.Spawner;

/**
 * InheritreeMature class representing the adult stage of the Inheritree.
 * Created by:
 * @author Richard Viera
 * Modified by:
 * @author Jackie Nguyen
 */
public class InheritreeMature extends GrowingStage {

    private final Spawner spawner;

    /**
     * Constructor for the InheritreeMature class.
     *
     * @param spawner spawner class which spawns Items around the location.
     * @param matureAge the age when the InheritreeMature stage matures.
     */
    public InheritreeMature(Spawner spawner, int matureAge) {
        super(matureAge, 'T');
        this.spawner = spawner;
    }

    /**
     * Represents the passing of time felt by the InheritreeMature object.
     *
     * @param location The location of the Ground.
     */
    @Override
    public void stageTickAction(Location location) {
        this.spawner.spawn(location);
        super.stageTickAction(location);
    }
}
