package game.grounds;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import game.attributes.Ability;

/**
 * A class that represents the floor inside a building.
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Richard Viera
 */
public class Floor extends Ground {

    /**
     * Constructor for the Floor class.
     */
    public Floor() {
        super('_');
    }

    /**
     * Returns the ability for an Actor to enter the Ground.
     *
     * @param actor the Actor to check.
     * @return true if the Actor has ability.ENTER_SPACESHIP in its capabilities, false otherwise.
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return actor.hasCapability(Ability.ENTER_SPACESHIP);
    }
}
