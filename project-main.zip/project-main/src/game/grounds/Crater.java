package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.spawners.Spawner;

/**
 * A class that represents a crater which spawns hostile actors.
 * Created by:
 * @author Richard Viera
 */
public class Crater extends Ground {

    private Spawner spawner;

    /**
     * Constructor for the Crater class.
     */
    public Crater(Spawner spawner) {
        super('u');
        this.spawner = spawner;
    }

    /**
     * Represents the passing of time which determines if it should spawn
     * actors or not at the current tick.
     *
     * @param location The location of the Ground.
     */
    @Override
    public void tick(Location location) {
        if(spawner != null){this.spawner.spawn(location);}
    }
}
