package game.grounds;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.ActorAttributeOperations;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.ConsumeAction;
import game.attributes.Consumable;

/**
 * A class that represents a puddle.
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Richard Viera
 */
public class Puddle extends Ground implements Consumable {

    /**
     * Constructor for the Puddle class.
     */
    public Puddle() {
        super('~');
    }

    /**
     * Returns the actions that an actor can perform on this Puddle.
     *
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return the allowable actions that can be done on the Puddle class.
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction) {
        ActionList actions = new ActionList();
        if (location.containsAnActor() && location.getActor() == actor) {
            actions.add(new ConsumeAction(this));
        }
        return actions;
    }

    /**
     * Adds the maximum of the Actor's health.
     *
     * @param consumer the Actor consuming the thing.
     * @return the String representing the feeling of the Actor.
     */
    @Override
    public String getConsumed(Actor consumer) {
        // increase maximum health by 1 point permanently
        consumer.modifyAttributeMaximum(BaseActorAttributes.HEALTH, ActorAttributeOperations.INCREASE, 1);
        return consumer + " feels invigorated";
    }

    /**
     * Gets the verb for consuming the Puddle.
     *
     * @return the verb for the action of consuming the Puddle.
     */
    @Override
    public String verb() {
        return "drinks";
    }

    /**
     * Method toString override for the Puddle class.
     *
     * @return the String name of the Puddle for String addition purposes.
     */
    @Override
    public String toString() {
        return "a random pool of water";
    }
}
