package game.attributes;

import edu.monash.fit2099.engine.actors.Actor;
/**
 * Interface defining the behaviors required for items that can be purchased within the game.
 * This interface ensures that any item that can be bought by an actor implements the necessary methods
 * to handle the purchase transaction and determine the purchase price.
 * Created by:
 * @author Khoa Ho
 * Modified by:
 * @author Richard Viera
 */
public interface Purchasable {
    /**
     * Handles the purchase of the item by an actor. This method should define the logic that occurs
     * when an item is purchased, which may include checking if the transaction is successful,
     * transferring the item to the buyer's inventory, and adjusting the buyer's credit or resources.
     *
     * @param buyer the actor attempting to purchase the item
     * @return a string message describing the outcome of the purchase; it could be null if the purchase
     * is successful and no special message is required, or it could contain details of why the purchase
     * failed or what effects it had.
     */
    String getPurchased(Actor buyer);
    /**
     * Returns the price of the item. This method should provide the logic to determine the cost of the item,
     * which could be a fixed amount or could vary depending on the game's state or special conditions.
     *
     * @return the purchase price of the item as an integer, which represents the amount of credits or currency
     * required to purchase the item.
     */
    int getPurchasePrice();
}
