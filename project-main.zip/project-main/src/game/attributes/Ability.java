package game.attributes;

/**
 * Enum to represent abilities.
 * Created by:
 * @author Richard Viera
 */
public enum Ability {

    /**
     * The ability to enter the spaceship.
     */
    ENTER_SPACESHIP,
    CAN_TRADE,
    CAN_BUY,
}
