package game.attributes;

import edu.monash.fit2099.engine.actors.Actor;

/**
 * Interface for consumable things.
 * Created by:
 * @author Richard Viera
 */
public interface Consumable {

    /**
     * Represents getting consumed by an Actor.
     *
     * @param consumer the Actor consuming the thing.
     * @return String with a message declaring the effects.
     */
    String getConsumed(Actor consumer);

    /**
     * Returns an action verb representing the act of consumption.
     *
     * @return the verb representing the consuming of the Consumable.
     */
    String verb();
}
