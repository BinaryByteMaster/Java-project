package game.attributes;

/**
 * Enum class to represent a status.
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Richard Viera
 */
public enum Status {

    /**
     * Hostile to enemy actors.
     */
    HOSTILE_TO_ENEMY,
    HOSTILE_TO_FRIENDLY,
}