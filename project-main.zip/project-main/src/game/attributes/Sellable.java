package game.attributes;

import edu.monash.fit2099.engine.actors.Actor;

/**
 * An interface representing an item that can be sold.
 * Classes implementing this interface should provide methods to determine the selling price
 * and perform the selling action.
 * Created by:
 * @author Xing Su
 */
public interface Sellable {
    /**
     * Method to perform the selling action.
     *
     * @param seller the actor selling the item
     * @return a message describing the selling action
     */
    String getSold(Actor seller);

    /**
     * Method to get the selling price of the item.
     *
     * @return the selling price of the item
     */
    int getSellPrice();
}