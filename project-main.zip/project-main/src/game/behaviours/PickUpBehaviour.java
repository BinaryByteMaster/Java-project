package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.items.PickUpAction;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;

import java.util.List;
import java.util.Random;

/**
 * A behaviour that makes the actor pick up scraps around itself.
 * Created by:
 * @author Xing Su
 * Modified by:
 * @author Richard Viera
 */

public class PickUpBehaviour implements Behaviour {

    /**
     * Returns a MoveAction to wander to a random location, if possible.
     * If no movement is possible, returns null.
     *
     * @param actor the Actor enacting the behaviour
     * @param map the map that actor is currently on
     * @return an Action, or null if no MoveAction is possible
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Location currentLocation = map.locationOf(actor);
        // attempt to pick up items if any are present
        if (!currentLocation.getItems().isEmpty()) {

            // randomly pick up any item on the ground tile
            List<Item> items = currentLocation.getItems();
            return new PickUpAction(currentLocation.getItems().get((new Random()).nextInt(items.size())));
        }

        return null;
    }
}
