package game.behaviours;

import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.actions.MoveActorAction;
import edu.monash.fit2099.engine.actors.Behaviour;

/**
 * A class that figures out a MoveAction that will move the actor one step
 * closer to a target Actor.
 * @see edu.monash.fit2099.demo.mars.Application
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Xing Su
 */
public class FollowBehaviour implements Behaviour {

    private final Actor target;

    /**
     * Constructor for the FollowBehaviour class.
     *
     * @param target the target that is to be followed.
     */
    public FollowBehaviour(Actor target) {
        this.target = target;
    }

    /**
     * Logic for returning a move action that follows a target.
     *
     * @param actor the Actor acting.
     * @param map the GameMap containing the Actor.
     * @return the MoveAction instance appropriate to get closer to the target Actor.
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {

        Location currentLocation = map.locationOf(actor);
        Location targetLocation = map.locationOf(target);
        int currentDistance = distance(currentLocation, targetLocation);

        if (currentDistance == 1) {
            return new DoNothingAction();
        }

        for (Exit possibleExit : currentLocation.getExits()) {
            Location destination = possibleExit.getDestination();
            if (destination.canActorEnter(actor)) {
                int newDistance = distance(destination, targetLocation);
                if (newDistance < currentDistance) {
                    return new MoveActorAction(destination, possibleExit.getName());
                }
            }
        }

        return null;
    }

    /**
     * Compute the Manhattan distance between two locations.
     *
     * @param a the first location
     * @param b the first location
     * @return the number of steps between a and b if you only move in the four cardinal directions.
     */
    private int distance(Location a, Location b) {
        return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
    }
}