package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.InstantKillAction;
import game.attributes.Status;

import java.util.List;

/**
 * A behaviour that makes the actor instant kill another actor around it.
 * Created by:
 * @author Richard Viera
 */
public class InstantKillBehaviour implements Behaviour {

    private final Status status;

    /**
     * Constructor for the AttackBehaviour class where the attacker uses no weapons.
     *
     * @param status status value representing the status of the target.
     */
    public InstantKillBehaviour(Status status) {
        this.status = status;
    }

    /**
     * Checks for an appropriate target, if so then instant kill them, if not return nothing
     * Returns an instant kill action.
     *
     * @param actor the Actor acting.
     * @param map the GameMap containing the Actor.
     * @return message declaring the result of the action.
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Location currentLocation = map.locationOf(actor);
        List<Exit> exits = currentLocation.getExits();
        for (Exit exit : exits) {
            if (exit.getDestination().containsAnActor()) {
                Actor attackActor = exit.getDestination().getActor();
                if (attackActor.hasCapability(this.status)) {
                    return new InstantKillAction(attackActor);  // instantly kill the Intern if in proximity
                }
            }
        }

        return null;
    }
}
