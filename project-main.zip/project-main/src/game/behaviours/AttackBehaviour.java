package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.AttackAction;
import game.attributes.Status;
import java.util.ArrayList;
import java.util.Random;

/**
 * AttackBehaviour class representing the attacking behaviour of an Actor.
 * Created by:
 * @author Richard Viera
 */
public class AttackBehaviour implements Behaviour {

    private final Status status;

    /**
     * Constructor for the AttackBehaviour class where the attacker uses no weapons.
     *
     * @param status status value representing the status of the target.
     */
    public AttackBehaviour(Status status) {
        this.status = status;
    }

    /**
     * Returns the attacking action done because of this behaviour
     *
     * @param actor the Actor performing the attack.
     * @param map the GameMap containing the Actor.
     * @return the AttackAction instance which determines the target being attacked if any are available.
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        ArrayList<Action> actions = new ArrayList<>();

        for (Exit exit : map.locationOf(actor).getExits()) {
            Location destination = exit.getDestination();
            if (destination.containsAnActor() && destination.getActor().hasCapability(this.status)) {
                actions.add(new AttackAction(destination.getActor(), exit.getName()));
            }
        }

        if (!actions.isEmpty()) {
            return actions.get((new Random()).nextInt(actions.size()));
        }
        else {
            return null;
        }
    }
}
