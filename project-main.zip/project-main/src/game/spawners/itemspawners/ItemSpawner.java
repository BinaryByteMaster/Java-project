package game.spawners.itemspawners;

import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Location;
import game.spawners.Spawner;

import java.util.List;
import java.util.Random;

/**
 * Abstract class that serves as the foundation for any class that spawns items in the game.
 * This class handles the basic mechanism of item spawning based on a probability.
 * Created by:
 * @author Jackie Nguyen
 * Modified by:
 * @author Richard Viera, Xing Su
 */
public class ItemSpawner implements Spawner {

    private final int spawnChance;
    private final Item spawnItem;

    /**
     * Constructor that initializes the spawner with a specific spawn chance.
     * @param spawnChance The probability (in percentage) that this spawner will spawn an item at a given opportunity.
     * @param spawnItem The non transforming Item instance that will be spawned by the spawner.
     */
    public ItemSpawner(int spawnChance, Item spawnItem) {
        this.spawnChance = spawnChance;
        this.spawnItem = spawnItem;
    }


    /**
     * Attempts to spawn an item at the specified location based on the defined spawn chance.
     * If the spawning condition is met, an item is placed at a random exit of the given location.
     * @param location The centre location where the item may be spawned.
     */
    @Override
    public void spawn(Location location) {
        if ((new Random()).nextInt(100) < getChance()) {
            List<Exit> exits = location.getExits();
            exits.get((new Random()).nextInt(exits.size())).getDestination().addItem(this.spawnItem);
        }
    }

    /**
     * Retrieves the spawn chance of this item spawner.
     * @return The spawn chance as an integer percentage.
     */
    @Override
    public int getChance() {
        return spawnChance;
    }
}

