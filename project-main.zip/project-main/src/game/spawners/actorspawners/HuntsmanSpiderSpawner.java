package game.spawners.actorspawners;

import edu.monash.fit2099.engine.actors.Actor;
import game.actors.creatures.HuntsmanSpider;

/**
 * HuntsmanSpiderSpawner class that is responsible for spawning Huntsman Spiders.
 * Created by:
 * @author Jackie Nguyen
 * Modified by:
 * @author Richard Viera
 */
public class HuntsmanSpiderSpawner extends ActorSpawner {

    /**
     * Constructor for the HuntsmanSpiderSpawner class.
     *
     * @param spawnChance the chance of spawning of Actors.
     */
    public HuntsmanSpiderSpawner(int spawnChance) {
        super(spawnChance);
    }

    /**
     * Returns a new instance of Huntsman Spider.
     *
     * @return a new instance of the Actor subclass.
     */
    @Override
    protected Actor getNewActor() {
        return new HuntsmanSpider();
    }

}
