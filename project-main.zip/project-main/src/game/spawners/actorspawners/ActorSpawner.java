package game.spawners.actorspawners;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Location;
import game.spawners.Spawner;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Abstract ActorSpawner class that serves as the basis mechanic of all spawner that spawns Actors.
 * Created by:
 * @author Jackie Nguyen
 * Modified by:
 * @author Richard Viera
 */
public abstract class ActorSpawner implements Spawner {

    private final int spawnChance;

    /**
     * Constructor for the ActorSpawner class.
     *
     * @param spawnChance the chance of spawning of Actors.
     */
    public ActorSpawner(int spawnChance) {
        this.spawnChance = spawnChance;
    }

    /**
     * The method that spawns an instance of a new actor
     * Computes if the possible spaces that can be spawned
     *
     * @param location the location to be used as the centre for spawning.
     */
    @Override
    public void spawn(Location location) {
        if ((new Random()).nextInt(100) < getChance()) {
            Actor spawnActor = this.getNewActor();
            List<Location> locations = new ArrayList<>();
            for (Exit exit: location.getExits()) {
                if (exit.getDestination().canActorEnter(spawnActor)) {
                    locations.add(exit.getDestination());
                }
            }

            locations.get((new Random()).nextInt(locations.size())).addActor(spawnActor);
        }
    }

    /**
     * Returns the spawn chance.
     *
     * @return the chance of spawning.
     */
    @Override
    public int getChance() {
        return this.spawnChance;
    }


    /**
     * Returns the new instance of the Actor.
     *
     * @return a new instance of the Actor subclass.
     */
    protected abstract Actor getNewActor();
}
