package game.spawners.actorspawners;

import edu.monash.fit2099.engine.actors.Actor;
import game.actors.creatures.AlienBug;

/**
 * AlienBugSpawner class responsible for spawning Alien Bug.
 * Created by:
 * @author Jackie Nguyen
 * Modified by:
 * @author Richard Viera
 */
public class AlienBugSpawner extends ActorSpawner {

    /**
     * Constructor for the AlienBugSpawner class.
     *
     * @param spawnChance the chance of spawning of Actors.
     */
    public AlienBugSpawner(int spawnChance) {
        super(spawnChance);
    }

    /**
     * Returns a new instance of Alien Bug.
     *
     * @return a new instance of the Actor subclass.
     */
    @Override
    protected Actor getNewActor() {
        return new AlienBug();
    }
}
