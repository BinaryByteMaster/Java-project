package game.spawners.actorspawners;

import edu.monash.fit2099.engine.actors.Actor;
import game.actors.creatures.SuspiciousAstronaut;

/**
 * SuspiciousAstronautSpawner class that is responsible for spawning Suspicious Astronaut.
 * Created by:
 * @author Jackie Nguyen
 * Modified by:
 * @author Richard Viera
 */
public class SuspiciousAstronautSpawner extends ActorSpawner {

    /**
     * Constructor for the SuspiciousAstronautSpawner class.
     *
     * @param spawnChance the chance of spawning of Actors.
     */
    public SuspiciousAstronautSpawner(int spawnChance) {
        super(spawnChance);
    }

    /**
     * Returns a new instance of Suspicious Astronaut.
     *
     * @return a new instance of the Actor subclass.
     */
    @Override
    protected Actor getNewActor() {
        return new SuspiciousAstronaut();
    }
}
