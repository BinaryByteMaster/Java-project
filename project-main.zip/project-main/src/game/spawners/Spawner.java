package game.spawners;

import edu.monash.fit2099.engine.positions.Location;

/**
 * Spawner interface which represents the common methods for all spawners.
 * Created by:
 * @author Richard Viera
 */
public interface Spawner {

    /**
     * Gets the chance of spawning for the spawner.
     *
     * @return the chance of spawning.
     */
    int getChance();

    /**
     * Spawns entities with reference to the location.
     *
     * @param location the location from which the spawner should use as a centre.
     */
    void spawn(Location location);
}
