package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.attributes.Consumable;

/**
 * ConsumeAction class representing the action of consuming a thing.
 * Created by:
 * @author Richard Viera
 */
public class ConsumeAction extends Action {

    private final Consumable consumable;

    /**
     * Constructor for the ConsumeAction class.
     *
     * @param consumable the thing to be consumed.
     */
    public ConsumeAction(Consumable consumable) {
        this.consumable = consumable;
    }

    /**
     * Represents consuming the consumable.
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a String describing what happened and the effects of consuming the thing.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        return actor + " " + this.consumable.verb() + " " + consumable + " and " + this.consumable.getConsumed(actor);
    }

    /**
     * Returns the String displayed on the menu.
     *
     * @param actor The actor performing the action.
     * @return the String description of the action.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " " + this.consumable.verb() + " " + this.consumable;
    }
}
