package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;

/**
 * Action that allows an actor to travel to a different location.
 * Created by:
 * @author Khoa Hoang Dang Ho
 * Modified by:
 * @author Richard Viera
 */
public class TravelActorAction extends Action {
    private final Location mapLocation;
    private final String mapName;

    /**
     * Constructor for TravelActorAction.
     *
     * @param mapLocation the location to travel to.
     * @param mapName the name of the map where the location is.
     */
    public TravelActorAction(Location mapLocation, String mapName) {
        this.mapLocation = mapLocation;
        this.mapName = mapName;
    }

    /**
     * Executes the action of traveling to a new location.
     *
     * @param actor the actor performing the action.
     * @param map the current map the actor is on.
     * @return a descriptive string of the result of the action.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (mapLocation.containsAnActor()) {
            return actor + " cannot teleport there";
        } else {
            map.moveActor(actor, mapLocation);
            return actor + " arrived at " + mapLocation + " in " + mapName;
        }
    }

    /**
     * Returns a description of the action for the menu.
     *
     * @param actor the actor performing the action.
     * @return a string description for the menu.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " travels to " + mapName;
    }
}
