package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.positions.GameMap;

/**
 * InstantKillAction class representing the action of instantly killing an Actor.
 * Created by:
 * @author Xing Su
 * Modified by:
 * @author Richard Viera
 */
public class InstantKillAction extends Action {
    private final Actor target;

    /**
     * Constructor for the InstantKillAction class.
     *
     * @param target the Actor to instantly kill.
     */
    public InstantKillAction(Actor target) {
        this.target = target;
    }

    /**
     * Instantly makes the target Actor is implementation.
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return message declaring the target is dead.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        // removes the target instantly from the map
        this.target.hurt(this.target.getAttribute(BaseActorAttributes.HEALTH));
        return actor + " " + actor.getIntrinsicWeapon().verb() + " and instantly kills " + this.target + "\n" + this.target.unconscious(actor, map);
    }

    /**
     * Menu description of the action being performed.
     *
     * @param actor The actor performing the action.
     * @return String detailing the details of the kill action.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " " + actor.getIntrinsicWeapon().verb() + " and instantly kills " + this.target;
    }
}