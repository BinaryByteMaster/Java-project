package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.attributes.Purchasable;

/**
 * An action that allows an actor to purchase a purchasable item within the game.
 * This class encapsulates the logic necessary for an actor to initiate and complete
 * a purchase transaction, including checking if the actor has enough balance and
 * updating the actor's inventory and balance as needed.
 * Created by:
 * @author Khoa Hoang Dang Ho
 * Modified by:
 * @author Richard Viera
 */
public class PurchaseAction extends Action {

    private final Purchasable purchasable;

    /**
     * Constructor for creating a PurchaseAction for a specific item.
     *
     * @param purchasable the item that can be purchased, which implements the {@link Purchasable} interface
     */
    public PurchaseAction(Purchasable purchasable){
        this.purchasable =  purchasable;
    }

    /**
     * Executes the purchase transaction for the specified actor and updates the game state accordingly.
     * If the actor has sufficient balance, the item's purchase price is deducted from the actor's balance,
     * and the item may be added to the actor's inventory. The method returns a message describing the outcome.
     *
     * @param actor the actor attempting to make the purchase
     * @param map the game map, which might be used to update the actor's state or other game elements
     * @return a string message indicating whether the purchase was successful or if it failed due to insufficient balance
     */
    public String execute(Actor actor, GameMap map) {
        int purchasePrice = this.purchasable.getPurchasePrice();
        if (purchasePrice <= actor.getBalance()) {
            actor.deductBalance(purchasePrice);
            String returnMessage = this.purchasable.getPurchased(actor);
            if (returnMessage == null) {
                returnMessage = actor + " successfully purchased " + this.purchasable + " for " + purchasePrice + " credits";
            }
            return returnMessage;
        }
        return "You don't have enough balance";
    }

    /**
     * Provides a description of this action in the menu presented to the user.
     *
     * @param actor the actor for whom the menu is being constructed
     * @return a string describing the action, which informs the player that they can purchase the item
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " purchases " + this.purchasable;
    }
}
