package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.attributes.Sellable;

/**
 * A class representing the action of selling a sellable item.
 * This class extends {@link Action} and is used by actors to sell items.
 * Created by:
 * @author Xing Su
 */
public class SellAction extends Action {

    private final Sellable sellable;

    /**
     * Constructor for the SellAction class.
     *
     * @param sellable the sellable item to be sold
     */
    public SellAction(Sellable sellable){
        this.sellable =  sellable;
    }

    /**
     * Executes the sell action.
     *
     * @param actor the actor selling the item
     * @param map the current game map
     * @return a message describing the result of the sell action
     */
    public String execute(Actor actor, GameMap map) {
        int sellPrice = this.sellable.getSellPrice();
        actor.addBalance(sellPrice);
        String returnMessage = this.sellable.getSold(actor);
        if (returnMessage == null) {
            returnMessage = actor + " successfully sold " + this.sellable + " for " + sellPrice + " credits.";
        }
        return returnMessage;
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " sells " + this.sellable;
    }
}