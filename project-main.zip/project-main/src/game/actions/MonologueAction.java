package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;

import java.util.ArrayList;
import java.util.Random;

/**
 * Monologue action class that allows other object to start monologuing.
 * Created by:
 * @author Jackie Nguyen
 */
public class MonologueAction extends Action {
    private final ArrayList<String> monologueOptions;

    private final String entity;

    /**
     * Takes in an input of possible dialogue options.
     *
     * @param entity the entity delivering the monologue.
     * @param monologueOptions the possible monologues that can be delivered by the entity.
     */
    public MonologueAction(String entity,ArrayList<String> monologueOptions) {
        this.monologueOptions = monologueOptions;
        this.entity = entity;
    }

    /**
     * Chooses a random line, out of the given monologue options.
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the chosen monologue to be delivered.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        return entity + ": \"" + monologueOptions.get(new Random().nextInt(monologueOptions.size())) + "\"";
    }

    /**
     * The hint of what the item does, given to the player
     *
     * @param actor The actor performing the action.
     * @return String describing the action.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " listens to " + entity;
    }

}
