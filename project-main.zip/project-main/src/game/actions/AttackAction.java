package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.Weapon;

import java.util.Random;

/**
 * AttackAction class representing the action of attacking another Actor.
 * Modified by:
 * @author Richard Viera
 */
public class AttackAction extends Action {

    /**
     * The Actor that is to be attacked
     */
    private final Actor target;

    /**
     * The direction of incoming attack.
     */
    private final String direction;

    /**
     * Random number generator
     */
    private final Random rand = new Random();

    /**
     * Weapon used for the attack
     */
    private Weapon weapon;

    /**
     * Constructor for the AttackAction class.
     *
     * @param target the Actor to attack.
     * @param direction the direction where the attack should be performed (only used for display purposes).
     */
    public AttackAction(Actor target, String direction, Weapon weapon) {
        this.target = target;
        this.direction = direction;
        this.weapon = weapon;
    }

    /**
     * Constructor with intrinsic weapon as default.
     *
     * @param target the actor to attack.
     * @param direction the direction where the attack should be performed (only used for display purposes).
     */
    public AttackAction(Actor target, String direction) {
        this.target = target;
        this.direction = direction;
    }

    /**
     * Executes the attack.
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return a String representing the result of the execution.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (this.weapon == null) {
            this.weapon = actor.getIntrinsicWeapon();
        }

        if (!(this.rand.nextInt(100) < this.weapon.chanceToHit())) {
            return actor + " misses " + this.target + ".";
        }

        int damage = this.weapon.damage();
        String result = actor + " " + this.weapon.verb() + " " + this.target + " for " + damage + " damage.";
        this.target.hurt(damage);
        if (!this.target.isConscious()) {
            result += "\n" + this.target.unconscious(actor, map);
        }

        return result;
    }

    /**
     * Menu description of the action being performed.
     *
     * @param actor The actor performing the action.
     * @return String detailing the details of the attack action including the direction and weapon.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " attacks " + this.target + " at " + this.direction + " with " + (this.weapon != null ? this.weapon : "Intrinsic Weapon");
    }
}
