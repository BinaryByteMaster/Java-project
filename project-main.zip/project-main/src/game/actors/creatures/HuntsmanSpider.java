package game.actors.creatures;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.actions.AttackAction;
import game.behaviours.AttackBehaviour;
import game.behaviours.WanderBehaviour;
import game.attributes.Status;

import java.util.Map;
import java.util.TreeMap;

/**
 * Class representing a Huntsman Spider.
 * Created by:
 * @author Richard Viera
 * Modified by:
 * @author Xing Su
 */
public class HuntsmanSpider extends Actor {
    public static final int ATTACK_BEHAVIOUR_INDEX = 98;
    public static final int WANDER_BEHAVIOUR_INDEX = 99;

    private Status enemyStatus = Status.HOSTILE_TO_ENEMY;
    private Map<Integer, Behaviour> behaviours = new TreeMap<>();

    /**
     * Constructor for the HuntsmanSpider class.
     */
    public HuntsmanSpider() {
        super("Huntsman Spider", '8', 1);
        this.addBehaviour(ATTACK_BEHAVIOUR_INDEX, new AttackBehaviour(Status.HOSTILE_TO_ENEMY));
        this.addBehaviour(WANDER_BEHAVIOUR_INDEX, new WanderBehaviour());
        this.addCapability(Status.HOSTILE_TO_FRIENDLY);
    }

    /**
     * Adds a new behaviour to the HuntsmanSpider.
     *
     * @param key the key for the behaviour.
     * @param newBehaviour the behaviour to add.
     */
    public void addBehaviour(int key, Behaviour newBehaviour) {
        this.behaviours.put(key, newBehaviour);
    }

    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(this.enemyStatus)) {
            actions.add(new AttackAction(this, direction));
        }
        return actions;
    }

    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        for (Behaviour behaviour : this.behaviours.values()) {
            Action action = behaviour.getAction(this, map);
            if (action != null)
                return action;
        }
        return new DoNothingAction();
    }

    @Override
    public String unconscious(Actor actor, GameMap map) {
        for (Item item : this.getItemInventory()) {
            map.locationOf(this).addItem(item);
        }
        return super.unconscious(actor, map);
    }

    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(1, "bites", 25);
    }
}