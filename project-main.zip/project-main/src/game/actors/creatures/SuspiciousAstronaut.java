package game.actors.creatures;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.AttackAction;
import game.attributes.Status;
import game.behaviours.InstantKillBehaviour;
import game.behaviours.WanderBehaviour;

import java.util.Map;
import java.util.TreeMap;

/**
 * Class representing a Suspicious Astronaut.
 * Created by:
 * @author Jackie Nguyen
 * Modified by:
 * @author Xing Su, Richard Viera
 */
public class SuspiciousAstronaut extends Actor {

    public static final int INSTANT_KILL_BEHAVIOUR_INDEX = 95;
    public static final int WANDER_BEHAVIOUR_INDEX = 99;

    private Map<Integer, Behaviour> behaviours = new TreeMap<>();

    /**
     * Constructor for the SuspiciousAstronaut class.
     */
    public SuspiciousAstronaut() {
        super("Among Us", 'ඞ', 99);
        this.addCapability(Status.HOSTILE_TO_ENEMY);
        this.addCapability(Status.HOSTILE_TO_FRIENDLY);

        this.addBehaviour(INSTANT_KILL_BEHAVIOUR_INDEX, new InstantKillBehaviour(Status.HOSTILE_TO_ENEMY));
        this.addBehaviour(WANDER_BEHAVIOUR_INDEX, new WanderBehaviour());
    }

    /**
     * Adds a new behaviour to the SuspiciousAstronaut.
     *
     * @param key the key for the behaviour.
     * @param newBehaviour the behaviour to add.
     */
    public void addBehaviour(int key, Behaviour newBehaviour) {
        this.behaviours.put(key, newBehaviour);
    }

    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        for (Behaviour behaviour : this.behaviours.values()) {
            Action action = behaviour.getAction(this, map);
            if (action != null)
                return action;
        }

        return new DoNothingAction();
    }

    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)) {
            actions.add(new AttackAction(this, direction));
        }
        return actions;
    }
}