package game.actors.creatures;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.AttackAction;
import game.attributes.Ability;
import game.attributes.Status;
import game.behaviours.FollowBehaviour;
import game.behaviours.PickUpBehaviour;
import game.behaviours.WanderBehaviour;

import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 * Class representing an Alien Bug.
 * Created by:
 * @author Jackie Nguyen
 * Modified by:
 * @author Xing Su, Richard Viera
 */
public class AlienBug extends Actor {
    public static final int FOLLOW_BEHAVIOUR_INDEX = 1;
    private static final int PICK_UP_BEHAVIOUR_INDEX = 0;
    private static final int WANDER_BEHAVIOUR_INDEX = 2;
    private Status enemyStatus = Status.HOSTILE_TO_ENEMY;
    private Map<Integer, Behaviour> behaviours = new TreeMap<>();

    /**
     * Constructor for the AlienBug class.
     */
    public AlienBug() {
        super("Feature-" + (new Random()).nextInt(10) + (new Random()).nextInt(10) + (new Random()).nextInt(10), 'a', 2);
        this.addBehaviour(PICK_UP_BEHAVIOUR_INDEX, new PickUpBehaviour());
        this.addBehaviour(WANDER_BEHAVIOUR_INDEX, new WanderBehaviour());
        this.addCapability(Ability.ENTER_SPACESHIP);
        this.addCapability(Status.HOSTILE_TO_FRIENDLY);
    }

    /**
     * Adds a new behaviour to the AlienBug.
     *
     * @param key the key for the behaviour.
     * @param newBehaviour the behaviour to add.
     */
    public void addBehaviour(int key, Behaviour newBehaviour) {
        this.behaviours.put(key, newBehaviour);
    }

    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        if (otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)) {
            this.addBehaviour(FOLLOW_BEHAVIOUR_INDEX, new FollowBehaviour(otherActor));
        }
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(this.enemyStatus)) {
            actions.add(new AttackAction(this, direction));
        }
        return actions;
    }

    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        for (Behaviour behaviour : this.behaviours.values()) {
            Action action = behaviour.getAction(this, map);
            if (action != null)
                return action;
        }
        return new DoNothingAction();
    }

    @Override
    public String unconscious(Actor actor, GameMap map) {
        for (Item item : this.getItemInventory()) {
            map.locationOf(this).addItem(item);
        }
        return super.unconscious(actor, map);
    }
}