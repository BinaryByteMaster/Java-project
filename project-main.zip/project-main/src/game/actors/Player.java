package game.actors;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.displays.Menu;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.displays.FancyMessage;
import game.attributes.Ability;
import game.attributes.Status;

/**
 * Class representing the Player.
 * Created by:
 * @author Adrian Kristanto
 * Modified by:
 * @author Richard Viera
 */
public class Player extends Actor {
    /**
     * Constructor for the Player class.
     *
     * @param name        Name to call the player in the UI.
     * @param displayChar Character to represent the player in the UI.
     * @param hitPoints   Player's starting number of hitpoints.
     */
    public Player(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        this.addCapability(Status.HOSTILE_TO_ENEMY);
        this.addCapability(Ability.ENTER_SPACESHIP);
        this.addCapability(Ability.CAN_TRADE);
    }

    /**
     * Represents a turn of the game for the Player.
     *
     * @param actions    collection of possible Actions for this Actor.
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction().
     * @param map        the map containing the Actor.
     * @param display    the I/O object to which messages may be written.
     * @return the Action instance chosen by the player.
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        if (super.getAttribute(BaseActorAttributes.HEALTH) <= 0) {
            display.print(this.unconscious(map));
            return new DoNothingAction();
        }

        // Handle multi-turn Actions
        if (lastAction.getNextAction() != null)
            return lastAction.getNextAction();

        // Print the player's name and current health
        String[] strings = this.toString().split(" ");
        for (int i = 0; i < strings.length - 1; i++) {
            display.print(strings[i] + " ");
        }
        display.print("\n");
        display.println("HP: " + super.getAttribute(BaseActorAttributes.HEALTH) + "/" + super.getAttributeMaximum(BaseActorAttributes.HEALTH));
        display.println("Balance:"+ super.getBalance());
        // Return/print the console menu
        Menu menu = new Menu(actions);
        return menu.showMenu(this, display);
    }

    /**
     * Represents when the Player's health reaches 0 without other Actor's influence.
     *
     * @param map where the actor fell unconscious.
     * @return a fancy message declaring the game is over.
     */
    @Override
    public String unconscious(GameMap map) {
        super.unconscious(map);
        return FancyMessage.YOU_ARE_FIRED;
    }

    /**
     * Represents when the Player's health reaches 0 because of other Actor's influence
     *
     * @param actor the perpetrator.
     * @param map where the actor fell unconscious.
     * @return a fancy message declaring the game is over.
     */
    @Override
    public String unconscious(Actor actor, GameMap map) {
        return this.unconscious(map);
    }

    /**
     * Gets the intrinsic weapon used by the Player
     *
     * @return the intrinsic weapon of the Player.
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(1, "punches", 5);
    }
}