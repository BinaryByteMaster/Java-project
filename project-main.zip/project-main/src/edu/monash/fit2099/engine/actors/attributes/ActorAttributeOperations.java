package edu.monash.fit2099.engine.actors.attributes;

public enum ActorAttributeOperations {
    INCREASE,
    DECREASE,
    UPDATE
}
