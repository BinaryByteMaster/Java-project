# FIT2099 Assignment (Semester 1, 2024)
# Static Factory

Contribution Log: https://docs.google.com/spreadsheets/d/1zo9LlYEjPvf4oKmSt0DBQqdS4O34yF2OWTSM07lv3L0/edit?usp=sharing